# app.py

import streamlit as st
import time
import torch
import numpy as np
from env.custom_env import CustomRoadEnv
from model.dqn_model import DQN
from eval.evaluate_agent import evaluate_and_get_path


def draw_road(road, car_pos):
    """Draw the current state of the road with car position."""
    display = []
    for i in range(3):  # 3 lanes
        row = ""
        for j in range(road.shape[1]):
            if (i, j) == car_pos:
                row += "🚗 "
            elif road[i, j] == 'S':
                row += "🚦 "
            elif road[i, j] == 'G':
                row += "🏁 "
            elif road[i, j] == 'O':
                row += "🕳️ "
            elif road[i, j] == 'V':
                row += "🚴 "
            else:
                row += "⬜ "
        display.append(row)
    return "\n".join(display)


# Streamlit UI setup
st.set_page_config(page_title="Smart Path-Finding Car", layout="wide")
st.title("🚗 Smart Path-Finding Car Simulation")

# Sidebar / Control panel
st.sidebar.header("🚧 Environment Settings")
mode = st.sidebar.selectbox("Select Mode", ['eval'])
Path_holes = st.sidebar.slider("Number of Path_holes", 1, 20, 5)
vehicles = st.sidebar.slider("Number of Other Vehicles", 0, 5, 1)
road_length = st.sidebar.slider("Road Length (in units)", 10, 50, 20)
unit = st.sidebar.selectbox("Distance Unit", ['Meters', 'Kilometers'])

# Convert length to units
unit_conversion = {
    'Meters': 100,
    'Kilometers': 0.1,
}
converted_length = road_length * unit_conversion[unit]
st.markdown(f"🛣️ **Total Road Distance:** {converted_length:.2f} {unit}")

# Run simulation button
if st.button("▶️ Run Simulation"):
    st.subheader("🛰️ Running Simulation...")

    # Evaluate and simulate
    path, env, result_text = evaluate_and_get_path(Path_holes, road_length, vehicles)

    # Show car animation
    placeholder = st.empty()
    for step, pos in enumerate(path):
        with placeholder.container():
            st.markdown(
                f"<div style='font-size: 30px; line-height: 1.1; text-align: center; white-space: pre;'>{draw_road(env.road, pos)}</div>",
                unsafe_allow_html=True
            )
        time.sleep(0.5)

    # Result status
    if "✅" in result_text:
        st.success(result_text)
    else:
        st.error(result_text)

    # Show full path taken
    st.subheader("📍 Path Coordinates Taken:")
    if path:
        formatted_path = "\n".join([f"Step {i + 1}: {coord}" for i, coord in enumerate(path)])
        st.code(formatted_path, language="text")
    else:
        st.warning("No path was followed.")
