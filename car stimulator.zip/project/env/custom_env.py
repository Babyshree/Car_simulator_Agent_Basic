import numpy as np
import random

class CustomRoadEnv:
    def __init__(self, Path_holes, road_length, other_vehicles):
        self.length = road_length
        self.road = np.full((3, road_length), '_', dtype=str)

        self.start = (1, 0)
        self.goal = (1, road_length - 1)
        self.road[self.start] = 'S'
        self.road[self.goal] = 'G'

        self.place_objects('O', Path_holes)
        self.place_objects('V', other_vehicles)

    def place_objects(self, symbol, count):
        placed = 0
        max_attempts = 1000
        attempts = 0

        while placed < count and attempts < max_attempts:
            x = random.randint(0, 2)
            y = random.randint(1, self.length - 2)  # avoid start and goal

            if self.road[x, y] != '_':
                attempts += 1
                continue

            if all(self.road[row, y] != '_' for row in range(3)):
                attempts += 1
                continue

            adjacent_blocked = False
            for dx in [-1, 0, 1]:
                nx = x + dx
                if 0 <= nx < 3 and self.road[nx, y] in ['O', 'V']:
                    adjacent_blocked = True
                    break

            if adjacent_blocked:
                attempts += 1
                continue

            self.road[x, y] = symbol
            placed += 1
            attempts = 0

        if placed < count:
            print(f"⚠️ Warning: Only placed {placed} out of {count} {symbol}s due to space constraints.")

    def reset(self):
        return self.road

    def step(self, action, pos):
        dx = [-1, 0, 1]  # left, forward, right
        next_x = max(0, min(2, pos[0] + dx[action]))
        next_y = pos[1] + 1

        done = False
        reward = 0

        # If out of bounds
        if next_y >= self.length:
            done = True
            return pos, -1, done, {}

        cell = self.road[next_x, next_y]

        if cell in ['O', 'V']:
            # Try to find alternate lane
            alternate_found = False
            for alt_x in range(3):
                if alt_x != next_x and self.road[alt_x, next_y] not in ['O', 'V']:
                    # Safe to change lane
                    next_x = alt_x
                    cell = self.road[next_x, next_y]
                    alternate_found = True
                    break

            if not alternate_found:
                reward = -1
                done = True
                return (next_x, next_y), reward, done, {}

        if (next_x, next_y) == self.goal:
            reward = 1
            done = True
        else:
            reward = -0.01

        return (next_x, next_y), reward, done, {}

    def display(self):
        for row in self.road:
            print(" ".join(row))

    def get_state(self, pos):
        grid = np.zeros((3, 15), dtype=int)
        for dy in range(15):
            y = pos[1] + dy
            if y >= self.length:
                break
            for dx in range(-1, 2):
                x = pos[0] + dx
                if 0 <= x < 3:
                    symbol = self.road[x, y]
                    grid[dx + 1, dy] = {
                        '_': 0, 'S': 0, 'G': 0,
                        'O': -1, 'V': -1
                    }.get(symbol, 0)
        return grid.flatten()
