from train.train_agent import train
from eval.evaluate_agent import evaluate_and_get_path

mode = input("Enter 'train' or 'eval': ").strip()
Path_holes = int(input("Enter number of Path_holes: "))
road_length = int(input("Enter road length: "))
vehicles = int(input("Enter number of other vehicles: "))

if mode == "train":
    train(Path_holes, road_length, vehicles)
elif mode == "eval":
    evaluate(Path_holes, road_length, vehicles)
