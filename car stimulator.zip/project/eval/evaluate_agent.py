# evaluate_agent.py
import torch
import numpy as np
from env.custom_env import CustomRoadEnv
from model.dqn_model import DQN

def is_goal_reachable(env, pos):
    current_y = pos[1]
    for lane in range(3):
        for offset in range(1, env.length - current_y):
            y = current_y + offset
            if env.road[lane, y] == 'G':
                if all(env.road[lane, current_y + step] not in ['O', 'V']
                       for step in range(1, offset + 1)):
                    return lane
    return None

def evaluate_and_get_path(Path_holes, road_length, vehicles):
    env = CustomRoadEnv(Path_holes, road_length, vehicles)
    model = DQN()
    model.load_state_dict(torch.load("model_checkpoint.pth"))
    model.eval()

    pos = list(env.start)
    path = [tuple(pos)]
    reached = False

    for _ in range(road_length + 5):
        state = env.get_state(pos)

        goal_lane = is_goal_reachable(env, pos)
        if goal_lane is not None and goal_lane != pos[0]:
            action = 0 if goal_lane < pos[0] else 2
        else:
            with torch.no_grad():
                q_values = model(torch.FloatTensor([state]))
                action = torch.argmax(q_values).item()

        next_pos, reward, done, _ = env.step(action, pos)
        pos = list(next_pos)
        path.append(tuple(pos))

        if done:
            reached = reward == 1
            break

    if not reached and pos[1] == env.goal[1] and pos[0] != 1:
        if env.road[1, pos[1]] not in ['O', 'V']:
            path.append((1, pos[1]))
            return path, env, "✅ Reached Goal by lane-switch at end!"

    return path, env, "✅ Reached Goal!" if reached else "❌ Hit obstacle or unreachable"
