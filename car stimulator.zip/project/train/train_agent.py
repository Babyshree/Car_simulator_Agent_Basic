import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np
from collections import deque
from env.custom_env import CustomRoadEnv
from model.dqn_model import DQN

def train(Path_holes=2, road_length=10, vehicles=1, episodes=5000
, seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    model = DQN()
    target_model = DQN()
    target_model.load_state_dict(model.state_dict())

    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.MSELoss()

    memory = deque(maxlen=10000)
    batch_size = 64
    gamma = 0.99
    epsilon = 1.0
    epsilon_decay = 0.995
    epsilon_min = 0.1

    for episode in range(episodes):
        env = CustomRoadEnv(Path_holes, road_length, vehicles)
        pos = list(env.start)
        state = env.get_state(pos)
        total_reward = 0

        for _ in range(road_length + 5):  
            if random.random() < epsilon:
                action = random.randint(0, 2)
            else:
                with torch.no_grad():
                    state_tensor = torch.from_numpy(np.array([state])).float()
                    action = torch.argmax(model(state_tensor)).item()

            next_pos, reward, done, _ = env.step(action, pos)
            next_state = env.get_state(next_pos)

            memory.append((state, action, reward, next_state, done))
            pos = list(next_pos)
            state = next_state
            total_reward += reward

            if done:
                break

        if len(memory) >= batch_size:
            batch = random.sample(memory, batch_size)
            states, actions, rewards, next_states, dones = zip(*batch)

            states = torch.FloatTensor(np.array(states))
            actions = torch.LongTensor(actions).unsqueeze(1)
            rewards = torch.FloatTensor(rewards).unsqueeze(1)
            next_states = torch.FloatTensor(np.array(next_states))
            dones = torch.BoolTensor(dones).unsqueeze(1)

            q_values = model(states).gather(1, actions)
            next_q = target_model(next_states).max(1, keepdim=True)[0].detach()
            targets = rewards + gamma * next_q * (~dones)

            loss = criterion(q_values, targets)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        if episode % 10 == 0:
            target_model.load_state_dict(model.state_dict())

        if epsilon > epsilon_min:
            epsilon *= epsilon_decay

        if episode % 50 == 0:
            print(f"Episode {episode}, Total Reward: {total_reward:.2f}, Epsilon: {epsilon:.3f}")

    torch.save(model.state_dict(), "model_checkpoint.pth")
